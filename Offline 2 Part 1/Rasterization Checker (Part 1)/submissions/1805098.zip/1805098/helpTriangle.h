#include "helpPoint.h"
#include <bits/stdc++.h>
using namespace std;

class Triangle

{
    //for 3 I don't need to use array
    Point p1, p2, p3;


    public:
    Triangle()
    {
        
    }

    Triangle(Point p1, Point p2, Point p3)
    {
        this->p1 = p1;
        this->p2 = p2;
        this->p3 = p3;

    }
};